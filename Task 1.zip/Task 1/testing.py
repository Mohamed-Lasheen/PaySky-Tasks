import requests
import os
from dotenv import load_dotenv

load_dotenv()

PAYMOB_API_KEY = os.getenv("PAYMOB_API_KEY")
PAYMOB_INTEGRATION_ID = os.getenv("PAYMOB_INTEGRATION_ID")

# Step 1: Authenticate with API Key
auth_response = requests.post(
    "https://accept.paymob.com/api/auth/tokens",
    json={"api_key": PAYMOB_API_KEY},
    timeout=10
)

print("Auth Status:", auth_response.status_code)
print("Auth Response:", auth_response.text)

if auth_response.status_code == 201:
    token = auth_response.json().get("token")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # Step 2: Create test order
    order_payload = {
        "amount_cents": 1000,  # 10.00 EGP
        "currency": "EGP",
        "delivery_needed": False,
        "items": []
    }

    order_response = requests.post(
        "https://accept.paymob.com/api/ecommerce/orders",
        json=order_payload,
        headers=headers,
        timeout=10
    )

    print("Order Status:", order_response.status_code)
    print("Order Response:", order_response.text)

    if order_response.status_code == 201:
        order_id = order_response.json().get("id")

        # Step 3: Try creating a payment key with your integration ID
        payment_key_payload = {
        "amount_cents": 1000,
        "currency": "EGP",
        "order_id": order_id,
        "integration_id": int(PAYMOB_INTEGRATION_ID),
        "billing_data": {
            "apartment": "N/A",
            "floor": "N/A",
            "building": "N/A",
            "street": "Test Street",
            "city": "Cairo",
            "state": "Cairo",
            "country": "EG",
            "first_name": "Test",
            "last_name": "User",
            "email": "test@example.com",
            "phone_number": "+201234567890",
            "postal_code": "12345"
        }
    }


        payment_key_response = requests.post(
            "https://accept.paymob.com/api/acceptance/payment_keys",
            json=payment_key_payload,
            headers=headers,
            timeout=10
        )

        print("Payment Key Status:", payment_key_response.status_code)
        print("Payment Key Response:", payment_key_response.text)
