import random
import time
import json
import os

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, jsonify, flash
)
from flask_session import Session
import requests
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev")
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# ─────────────────────────────────────────────────────────────
# Paymob (Legacy 3-Step) Config
# ─────────────────────────────────────────────────────────────
PAYMOB_BASE_URL = "https://accept.paymob.com"
PAYMOB_API_KEY = os.getenv("PAYMOB_API_KEY")  # Required for /api/auth/tokens
PAYMOB_INTEGRATION_ID = os.getenv("PAYMOB_INTEGRATION_ID")  # Your MIGS (Card) integration ID (e.g., 5269050)
PAYMOB_IFRAME_ID = os.getenv("PAYMOB_IFRAME_ID")  # From Dashboard → Payment Integrations

# Mock API (catalog)
PRODUCTS_API = "https://fakestoreapi.com/products"

# ─────────────────────────────────────────────────────────────
# Simple in-memory "users" store (email -> record)
# (Fixes earlier bug where it wasn't keyed by email)
# ─────────────────────────────────────────────────────────────
registered_users = {
    "test@example.com": {
        "password": "password123",
        "first_name": "Test",
        "last_name": "User",
        "email": "test@example.com",
        "phone": "+201010276462",
        "address": "123 Test Street",
        "city": "Cairo",
        "zip_code": "12345",
        "state": "Cairo"
    }
}

# ─────────────────────────────────────────────────────────────
# Cart model
# ─────────────────────────────────────────────────────────────
class Cart:
    def __init__(self):
        self.items = []

    def add_item(self, product_id, product_data):
        for item in self.items:
            if str(item["id"]) == str(product_id):
                item["quantity"] += 1
                self._save_to_session()
                return
        new_item = {**product_data, "quantity": 1}
        self.items.append(new_item)
        self._save_to_session()

    def remove_item(self, product_id):
        for i, item in enumerate(self.items):
            if str(item["id"]) == str(product_id):
                self.items.pop(i)
                self._save_to_session()
                return True
        return False

    def update_quantity(self, product_id, quantity):
        for item in self.items:
            if str(item["id"]) == str(product_id):
                if quantity <= 0:
                    self.remove_item(product_id)
                else:
                    item["quantity"] = quantity
                    self._save_to_session()
                return

    def _save_to_session(self):
        session["cart"] = {"items": self.items}
        session.modified = True

    def get_item_count(self):
        return sum(item["quantity"] for item in self.items)

    def get_total(self):
        return sum(item["price"] * item["quantity"] for item in self.items)

    def clear(self):
        self.items = []
        self._save_to_session()

def get_cart():
    if "cart" not in session:
        session["cart"] = {"items": []}
    cart = Cart()
    if "cart" in session and "items" in session["cart"]:
        cart.items = session["cart"]["items"]
    return cart

def get_current_user():
    """
    Returns the current user's dict if logged in; otherwise a safe default.
    """
    email = session.get("user_email")
    if email and email in registered_users:
        return registered_users[email]
    # default fallback (still satisfies Paymob billing requirements)
    return {
        "first_name": "Customer",
        "last_name": "User",
        "email": "customer@example.com",
        "phone": "+201234567890",
        "address": "Test Street",
        "city": "Cairo",
        "zip_code": "12345",
        "state": "Cairo"
    }

# ─────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────
@app.route("/")
def home():
    return redirect(url_for("product_list"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        first_name = request.form["first_name"].strip()
        last_name = request.form["last_name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "Cairo").strip()
        zip_code = request.form.get("zip_code", "12345").strip()
        state = request.form.get("state", city or "Cairo").strip()

        if not all([first_name, last_name, email, password, confirm_password]):
            flash("Please fill in all required fields!")
            return redirect(url_for("register"))

        if password != confirm_password:
            flash("Passwords do not match!")
            return redirect(url_for("register"))

        if email in registered_users:
            flash("Email already registered! Please login instead.")
            return redirect(url_for("login"))

        registered_users[email] = {
            "password": password,
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
            "phone": phone or "+201234567890",
            "address": address or "Test Street",
            "city": city or "Cairo",
            "zip_code": zip_code or "12345",
            "state": state or "Cairo"
        }

        session["user_id"] = email
        session["user_email"] = email
        session["user_name"] = f"{first_name} {last_name}"
        flash(f"Registration successful! Welcome {first_name}!")
        return redirect(url_for("product_list"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("product_list"))

    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        user = registered_users.get(email)
        if user and user["password"] == password:
            session["user_id"] = email
            session["user_email"] = email
            session["user_name"] = f"{user['first_name']} {user['last_name']}"
            flash("Login successful! Welcome back!")
            return redirect(url_for("product_list"))

        flash("Invalid email or password!")
        return redirect(url_for("login"))

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("login"))

@app.route("/product_list")
def product_list():
    try:
        response = requests.get(PRODUCTS_API, timeout=7)
        response.raise_for_status()
        products = response.json()
        cart = get_cart()
        cart_count = cart.get_item_count()
        return render_template("products.html", products=products, cart_count=cart_count)
    except requests.exceptions.RequestException:
        return render_template("error.html", message="Failed to load products"), 500

def save_cart_to_session(cart):
    session["cart"] = {"items": cart.items}
    session.modified = True

@app.route("/update-cart/<product_id>", methods=["POST"])
def update_cart(product_id):
    cart = get_cart()
    action = request.form.get("action")

    for item in cart.items:
        if str(item["id"]) == str(product_id):
            if action == "increase":
                item["quantity"] += 1
            elif action == "decrease" and item["quantity"] > 1:
                item["quantity"] -= 1
            break

    save_cart_to_session(cart)
    return redirect(url_for("view_cart"))

@app.route("/clear-cart", methods=["POST"])
def clear_cart():
    cart = get_cart()
    cart.clear()
    save_cart_to_session(cart)
    return redirect(url_for("view_cart"))

@app.route("/add-to-cart/<product_id>", methods=["POST"])
def add_to_cart(product_id):
    try:
        response = requests.get(f"{PRODUCTS_API}/{product_id}", timeout=5)
        response.raise_for_status()
        product = response.json()

        cart = get_cart()
        for item in cart.items:
            if str(item["id"]) == str(product_id):
                item["quantity"] += 1
                save_cart_to_session(cart)
                flash(f'Increased quantity: {product["title"]}')
                return redirect(url_for("product_list"))

        cart.add_item(product_id, {
            "id": product["id"],
            "title": product["title"],
            "price": product["price"],
            "image": product.get("image", "")
        })
        save_cart_to_session(cart)
        flash(f'Added {product["title"]} to cart!')
        return redirect(url_for("product_list"))

    except requests.exceptions.RequestException:
        return render_template("error.html", message="Failed to add item to cart"), 500

@app.route("/cart")
def view_cart():
    cart = get_cart()
    cart_items = cart.items
    total = cart.get_total()
    cart_count = cart.get_item_count()
    return render_template("cart.html", cart_items=cart_items, total=total, cart_count=cart_count)

@app.route("/remove-from-cart/<product_id>", methods=["POST"])
def remove_from_cart(product_id):
    cart = get_cart()
    cart.remove_item(product_id)
    session.modified = True
    return redirect(url_for("view_cart"))

@app.route("/checkout")
def checkout():
    if "user_id" not in session:
        flash("Please login first!")
        return redirect(url_for("login"))

    cart = get_cart()
    if not cart.items:
        flash("Your cart is empty!")
        return redirect(url_for("view_cart"))

    total = cart.get_total()
    cart_count = cart.get_item_count()
    return render_template(
        "checkout.html",
        total=total,
        cart_count=cart_count,
        cart_items=cart.items
    )

# ─────────────────────────────────────────────────────────────
# Paymob (Legacy 3-Step) helpers
# ─────────────────────────────────────────────────────────────
def paymob_auth_token():
    if not PAYMOB_API_KEY:
        raise ValueError("PAYMOB_API_KEY is missing")
    r = requests.post(
        f"{PAYMOB_BASE_URL}/api/auth/tokens",
        json={"api_key": PAYMOB_API_KEY},
        timeout=30
    )
    print("Auth:", r.status_code, r.text)
    if r.status_code == 201:
        return r.json().get("token")
    raise RuntimeError(f"Auth failed: {r.status_code} - {r.text}")

def paymob_create_order(token: str, amount_cents: int):
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "amount_cents": amount_cents,
        "currency": "EGP",
        "delivery_needed": False,
        "items": []
    }
    r = requests.post(
        f"{PAYMOB_BASE_URL}/api/ecommerce/orders",
        json=payload,
        headers=headers,
        timeout=30
    )
    print("Order:", r.status_code, r.text)
    if r.status_code == 201:
        return r.json()["id"]
    raise RuntimeError(f"Order failed: {r.status_code} - {r.text}")

def paymob_payment_key(token: str, order_id: int, amount_cents: int, user: dict):
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    # Required billing_data fields for card
    billing = {
        "apartment": user.get("apartment", "N/A"),
        "floor": user.get("floor", "N/A"),
        "building": user.get("building", "N/A"),
        "street": user.get("address", "Test Street"),
        "city": user.get("city", "Cairo"),
        "state": user.get("state", user.get("city", "Cairo")),
        "country": "EG",  # ISO2 for legacy flow
        "first_name": user.get("first_name", "Customer"),
        "last_name": user.get("last_name", "User"),
        "email": user.get("email", "customer@example.com"),
        "phone_number": user.get("phone", "+201234567890"),
        "postal_code": user.get("zip_code", "12345")
    }
    payload = {
        "amount_cents": amount_cents,
        "currency": "EGP",
        "order_id": order_id,
        "integration_id": int(PAYMOB_INTEGRATION_ID),
        "billing_data": billing
    }
    r = requests.post(
        f"{PAYMOB_BASE_URL}/api/acceptance/payment_keys",
        json=payload,
        headers=headers,
        timeout=30
    )
    print("PaymentKey:", r.status_code, r.text)
    if r.status_code == 201:
        return r.json()["token"]
    raise RuntimeError(f"Payment key failed: {r.status_code} - {r.text}")

# ─────────────────────────────────────────────────────────────
# Create payment (legacy flow) – keeps your old URL so your HTML works
# ─────────────────────────────────────────────────────────────
@app.route("/create-payment-intent", methods=["POST"])
def create_payment_intent():
    try:
        if not all([PAYMOB_API_KEY, PAYMOB_INTEGRATION_ID, PAYMOB_IFRAME_ID]):
            return jsonify({
                "error": "Payment configuration incomplete. Check PAYMOB_API_KEY, PAYMOB_INTEGRATION_ID, PAYMOB_IFRAME_ID."
            }), 500

        cart = get_cart()
        if not cart.items:
            return jsonify({"error": "Cart is empty"}), 400

        # Amount in cents
        total_amount_cents = int(round(cart.get_total() * 100))
        user = get_current_user()

        # 1) auth
        token = paymob_auth_token()
        # 2) order
        order_id = paymob_create_order(token, total_amount_cents)
        # 3) payment key
        payment_token = paymob_payment_key(token, order_id, total_amount_cents, user)

        # Build iframe checkout URL
        checkout_url = f"{PAYMOB_BASE_URL}/api/acceptance/iframes/{PAYMOB_IFRAME_ID}?payment_token={payment_token}"

        # Save to session (optional)
        session["paymob_order_id"] = order_id
        session["paymob_payment_token"] = payment_token

        return jsonify({"success": True, "checkout_url": checkout_url})

    except Exception as e:
        print("Payment error:", str(e))
        return jsonify({"error": str(e)}), 500

@app.route("/process-payment")
def process_payment():
    """
    Optional: if you want a server redirect rather than client-side script redirect.
    """
    payment_token = session.get("paymob_payment_token")
    if not payment_token or not PAYMOB_IFRAME_ID:
        flash("Payment session expired. Please try again.")
        return redirect(url_for("checkout"))
    checkout_url = f"{PAYMOB_BASE_URL}/api/acceptance/iframes/{PAYMOB_IFRAME_ID}?payment_token={payment_token}"
    return redirect(checkout_url)

# ─────────────────────────────────────────────────────────────
# Webhook
# ─────────────────────────────────────────────────────────────
@app.route("/paymob-webhook", methods=["POST"])
def paymob_webhook():
    try:
        data = request.get_json(force=True, silent=True) or {}
        print("Webhook:", json.dumps(data, indent=2))

        # Minimal example – adjust to your webhook schema & signature verification if enabled
        obj = data.get("obj", {})
        success = obj.get("success")
        order_id = obj.get("order", {}).get("id")
        amount_egp = (obj.get("amount_cents", 0) or 0) / 100.0

        if success:
            print(f"[Webhook] Payment success for order {order_id}, amount {amount_egp} EGP")
            # TODO: mark order paid in your DB
        else:
            print(f"[Webhook] Payment failed for order {order_id}")

        return jsonify({"status": "ok"}), 200
    except Exception as e:
        print("Webhook error:", str(e))
        return jsonify({"error": "Webhook processing failed"}), 500

@app.route("/payment-success")
def payment_success():
    if "user_id" not in session:
        flash("Please login first!")
        return redirect(url_for("login"))

    cart = get_cart()
    order_id = f"ORD{int(time.time())}{random.randint(1000, 9999)}"

    session["last_order"] = {
        "order_id": order_id,
        "total": cart.get_total(),
        "items": cart.items,
        "paymob_order_id": session.get("paymob_order_id")
    }

    cart.clear()
    session.pop("paymob_payment_token", None)
    session.pop("paymob_order_id", None)

    flash("Payment successful! Thank you for your order.")
    return render_template("success.html",
                           order_id=order_id,
                           total=session["last_order"]["total"])

@app.route("/payment-failed")
def payment_failed():
    error_message = request.args.get("message", "Payment failed. Please try again.")
    return render_template("failed.html",
                           error_message=error_message,
                           cart_count=get_cart().get_item_count())

if __name__ == "__main__":
    app.run(debug=True, port=5000)
