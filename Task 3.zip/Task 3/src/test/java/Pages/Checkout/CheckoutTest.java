package test;

import Pages.Registeration.Registeration;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import Pages.Login.Login;
import Pages.Cart.Cart;
import Pages.Checkout.Checkout;
import Pages.Confirmation.Confirmation;
import Pages.Products.Products;
import Utilities.Selenium.DriverFactory;
import Utilities.TestData.TestData;

public class CheckoutTest extends DriverFactory {

    @Parameters("baseUrl")
    @Test(dataProvider = "checkoutData")
    public void testCompleteCheckoutProcess(String productName, String email, String password,
                                            String firstName, String lastName, String address,
                                            String city, String postalCode, String country,
                                            String cardNumber, String expiry, String cvv) {

        WebDriver driver = getDriver();

        try {
            // 1. Login
            driver.get("https://practicesoftwaretesting.com/auth/login");
            final Login loginPage = new Login();
            loginPage.LoginWithValidUser();

            // 2. Select product and add to cart
            driver.get("https://practicesoftwaretesting.com/products");
            Products productsPage = new Products(driver);
            productsPage.selectProduct(productName);
            productsPage.addToCart();

            // 3. Go to cart and verify
            productsPage.goToCart();
            Cart cartPage = new Cart(driver);
            Assert.assertTrue(cartPage.isProductInCart(), "Product should be in cart");

            // 4. Proceed to checkout
            cartPage.proceedToCheckout();

            // 5. Fill shipping and payment info
            Checkout checkoutPage = new Checkout(driver);
            checkoutPage.fillShippingInfo(firstName, lastName, address, city, postalCode, country);
            checkoutPage.fillPaymentInfo(cardNumber, expiry, cvv);

            // 6. Place order
            checkoutPage.placeOrder();

            // 7. Verify confirmation
            Confirmation confirmationPage = new Confirmation(driver);
            Assert.assertTrue(confirmationPage.isConfirmationDisplayed(),
                    "Order confirmation should be displayed");

            System.out.println("Order completed successfully. Order #: " +
                    confirmationPage.getOrderNumber());

        } catch (Exception e) {
            Assert.fail("Test failed: " + e.getMessage());
        }
    }

    @DataProvider(name = "checkoutData")
    public Object[][] getCheckoutTestData() {
        return TestData.getCheckoutTestData();
    }
}