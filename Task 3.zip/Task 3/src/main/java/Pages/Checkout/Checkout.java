package Pages.Checkout;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Checkout {
    WebDriver driver;

    // Shipping fields
    By firstName = By.id("first_name");
    By lastName = By.id("last_name");
    By address = By.id("address");
    By city = By.id("city");
    By postalCode = By.id("postalCode");
    By country = By.id("country");

    // Payment fields
    By cardNumber = By.id("cardNumber");
    By expiryDate = By.id("expiryDate");
    By cvv = By.id("cvv");

    By placeOrderButton = By.id("place-order");

    public Checkout(WebDriver driver) {
        this.driver = driver;
    }

    public void fillShippingInfo(String first, String last, String addr,
                                 String cityName, String zip, String countryName) {
        driver.findElement(firstName).sendKeys(first);
        driver.findElement(lastName).sendKeys(last);
        driver.findElement(address).sendKeys(addr);
        driver.findElement(city).sendKeys(cityName);
        driver.findElement(postalCode).sendKeys(zip);

        Select countrySelect = new Select(driver.findElement(country));
        countrySelect.selectByVisibleText(countryName);
    }

    public void fillPaymentInfo(String card, String expiry, String securityCode) {
        driver.findElement(cardNumber).sendKeys(card);
        driver.findElement(expiryDate).sendKeys(expiry);
        driver.findElement(cvv).sendKeys(securityCode);
    }

    public void placeOrder() {
        driver.findElement(placeOrderButton).click();
    }
}