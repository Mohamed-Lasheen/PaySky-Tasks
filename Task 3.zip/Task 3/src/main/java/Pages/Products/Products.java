package Pages.Products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class Products {
    WebDriver driver;

    By productLinks = By.cssSelector(".product-list .product");
    By addToCartButton = By.cssSelector(".add-to-cart");
    By cartIcon = By.id("cart");

    public Products(WebDriver driver) {
        this.driver = driver;
    }

    public void selectProduct(String productName) {
        List<WebElement> products = driver.findElements(productLinks);
        for (WebElement product : products) {
            if (product.getText().contains(productName)) {
                product.click();
                break;
            }
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartButton));
    }

    public void addToCart() {
        driver.findElement(addToCartButton).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();
    }

    public void goToCart() {
        driver.findElement(cartIcon).click();
    }
}