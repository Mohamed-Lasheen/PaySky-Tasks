package Pages.Cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class Cart {
    WebDriver driver;

    By checkoutButton = By.id("checkout");
    By cartItems = By.cssSelector(".cart-item");

    public Cart(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isProductInCart() {
        return driver.findElements(cartItems).size() > 0;
    }

    public void proceedToCheckout() {
        driver.findElement(checkoutButton).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlContains("checkout"));
    }
}