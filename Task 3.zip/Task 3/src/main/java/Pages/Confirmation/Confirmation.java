package Pages.Confirmation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class Confirmation{
    WebDriver driver;

    By confirmationMessage = By.cssSelector(".confirmation-message");
    By orderNumber = By.cssSelector(".order-number");

    public Confirmation(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isConfirmationDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmationMessage));
        return driver.findElement(confirmationMessage).isDisplayed();
    }

    public String getOrderNumber() {
        return driver.findElement(orderNumber).getText();
    }
}